$(document).ready(function () {

    $("#menu ul li:eq(1)").click(function () {
        $(".btnall").show();
        $(".name").hide();
        $("section").addClass("in");
        $("nav").addClass("in");
        $("#squre").addClass("in");
    });
    $("#btnmenu2").click(function () {
        $(".btnall").show();
        $(".name").hide();
        $("section").addClass("in");
        $("nav").addClass("in");
        $("#squre").addClass("in");
    });
});
$(function(){
    $(".btn2").click(function(){
        $(".pro-in").stop().animate({left:'-750px'},800);
        $(this).css({"background":"#fff","color":"#000"});
        $(".btn1").css({"background":"#000","color":"#fff"});
        $(".btn4").css({"background":"#000","color":"#fff"});
        $(".btn3").css({"background":"#000","color":"#fff"});
    });
    $(".btn1").click(function(){
        $(".pro-in").stop().animate({left:'0px'},800);
        $(this).css({"background":"#fff","color":"#000"});
        $(".btn2").css({"background":"#000","color":"#fff"});
        $(".btn4").css({"background":"#000","color":"#fff"});
        $(".btn3").css({"background":"#000","color":"#fff"});
    });
    $(".btn3").click(function(){
        $(".pro-in").stop().animate({left:'-1500px'},800);
        $(this).css({"background":"#fff","color":"#000"});
        $(".btn1").css({"background":"#000","color":"#fff"});
        $(".btn4").css({"background":"#000","color":"#fff"});
        $(".btn2").css({"background":"#000","color":"#fff"});
    });
    $(".btn4").click(function(){
        $(".pro-in").stop().animate({left:'-2250px'},800);
        $(this).css({"background":"#fff","color":"#000"});
        $(".btn1").css({"background":"#000","color":"#fff"});
        $(".btn2").css({"background":"#000","color":"#fff"});
        $(".btn3").css({"background":"#000","color":"#fff"});
    });
});
