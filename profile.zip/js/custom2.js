$(document).ready(function () {
    $("#btnmenu").click(function () {
        $(this).fadeOut();
        $("#btnmenu2").addClass("on");
        $("section").addClass("on");
        $("nav").addClass("on");
        $("#squre").addClass("on");
    });
    
});
$(function(){
    $(".btn2").click(function(){
        $(".in").stop().animate({left:'-1500px'},800);
        $(this).css({"border":"solid 2px #000","border-radius":"none"});
        $(".btn1").css({"border":"none","border-radius":"none"});
    });
    $(".btn1").click(function(){
        $(".in").stop().animate({left:'0px'},800);
        $(this).css({"border":"solid 2px #000","border-radius":"none"});
        $(".btn2").css({"border":"none","border-radius":"none"});
    });
    $('#squre2').click(function(){
        $('html, body').animate({scrollTop:0},200);
    });
});
